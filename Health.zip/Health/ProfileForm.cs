﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Health
{
    public partial class ProfileForm : Form
    {
        public ProfileForm()
        {
            InitializeComponent();
        }

        private void ProfileForm_Load(object sender, EventArgs e)
        {
            LoadProfile();  // Load user profile when the form is loaded
        }

        // Method to load the user profile into the DataGridView
        private void LoadProfile()
        {
            string query = @"SELECT UserID, FullName, Phone, Email, DOB, Gender, Role
                             FROM Users
                             WHERE UserID = @userId";

            using (SqlConnection connection = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@userId", Session.UserId); // Assuming Session.UserId holds the current user's ID

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dgvProfileForm.DataSource = dt;  // Bind data to DataGridView
                }
            }
        }

        // Event handler for the Update button click
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Create an instance of the UpdateProfileForm
            UpdateProfileForm updateForm = new UpdateProfileForm();

            // Show the UpdateProfileForm
            updateForm.Show();
            this.Hide();
        }

        // Event handler for the Back button click
        private void btnBack_Click(object sender, EventArgs e)
        {
            DashboardForm df = new DashboardForm();

            // Show the DashboardForm
            df.Show();

            // Hide the current ViewFamilyMembersForm
            this.Hide();
        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            DashboardForm df = new DashboardForm();

            // Show the DashboardForm
            df.Show();

            // Hide the current ViewFamilyMembersForm
            this.Hide();
        }
    }
}
