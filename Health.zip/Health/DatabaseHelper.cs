﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Health           // replace with your actual project namespace if different
{
    public static class DatabaseHelper
    {
        // Replace YOUR_SERVER_NAME with what you saw in SSMS
        public static string ConnectionString = @"Server=RIAJ-PROPERTY\SQLEXPRESS;Database=HEALTH_DB;Trusted_Connection=True;";

        public static SqlConnection GetConnection()
        {
            var conn = new SqlConnection(ConnectionString);
            conn.Open();
            return conn;
        }
    }
}
