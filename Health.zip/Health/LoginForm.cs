﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Health
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            SetupPlaceholders();
        }
        private void SetupPlaceholders()
        {
            // Email/Phone placeholder
            txtEmailPhone.Text = "Email address or phone number";
            txtEmailPhone.ForeColor = Color.Gray;
            txtEmailPhone.Enter += (s, e) =>
            {
                if (txtEmailPhone.Text == "Email address or phone number")
                {
                    txtEmailPhone.Text = "";
                    txtEmailPhone.ForeColor = Color.Black;
                }
            };
            txtEmailPhone.Leave += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtEmailPhone.Text))
                {
                    txtEmailPhone.Text = "Email address or phone number";
                    txtEmailPhone.ForeColor = Color.Gray;
                }
            };

            // Password placeholder
            txtPassword.Text = "Password";
            txtPassword.ForeColor = Color.Gray;
            txtPassword.UseSystemPasswordChar = false;
            txtPassword.Enter += (s, e) =>
            {
                if (txtPassword.Text == "Password")
                {
                    txtPassword.Text = "";
                    txtPassword.ForeColor = Color.Black;
                    txtPassword.UseSystemPasswordChar = true;
                }
            };
            txtPassword.Leave += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    txtPassword.UseSystemPasswordChar = false;
                    txtPassword.Text = "Password";
                    txtPassword.ForeColor = Color.Gray;
                }
            };
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string emailOrPhone = txtEmailPhone.Text.Trim();
            string password = txtPassword.Text.Trim();

            // Perform validation
            if (string.IsNullOrEmpty(emailOrPhone) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both Email/Phone and Password.", "Missing info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    // SQL query to validate login details
                    string sql = "SELECT UserID, FullName, Role FROM Users WHERE (Email = @id OR Phone = @id) AND Password = @pwd";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", emailOrPhone);
                        cmd.Parameters.AddWithValue("@pwd", password);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int userId = Convert.ToInt32(reader["UserID"]);
                                string userName = reader["FullName"].ToString();
                                string role = reader["Role"].ToString();

                                // Store the logged-in user's data in the Session class
                                Session.UserId = userId;
                                Session.UserName = userName;
                                Session.UserRole = role;

                                // Open the Dashboard form
                                var dashboardForm = new DashboardForm(Session.UserId, Session.UserName, Session.UserRole);
                                dashboardForm.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Invalid email/phone or password.", "Login failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("DB Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnSignUp_Click(object sender, EventArgs e)
        {
            var signup = new SignUpForm();
            signup.Show();
            this.Hide();
        }

        private void lnkForgotPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var fp = new ForgotPasswordForm();
            fp.Show();
            this.Hide();
        }
    }
}
