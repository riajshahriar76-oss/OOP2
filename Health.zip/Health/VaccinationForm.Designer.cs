﻿namespace Health
{
    partial class VaccinationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VaccinationForm));
            this.cmbFamilyMember = new System.Windows.Forms.ComboBox();
            this.txtVaccineName = new System.Windows.Forms.TextBox();
            this.txtTotalDoses = new System.Windows.Forms.TextBox();
            this.dtpDueDate = new System.Windows.Forms.DateTimePicker();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.btnAddVaccine = new System.Windows.Forms.Button();
            this.btnUpdateVaccine = new System.Windows.Forms.Button();
            this.dgvVaccination = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVaccination)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbFamilyMember
            // 
            this.cmbFamilyMember.FormattingEnabled = true;
            this.cmbFamilyMember.Location = new System.Drawing.Point(735, 111);
            this.cmbFamilyMember.Name = "cmbFamilyMember";
            this.cmbFamilyMember.Size = new System.Drawing.Size(294, 28);
            this.cmbFamilyMember.TabIndex = 0;
            // 
            // txtVaccineName
            // 
            this.txtVaccineName.Location = new System.Drawing.Point(733, 194);
            this.txtVaccineName.Name = "txtVaccineName";
            this.txtVaccineName.Size = new System.Drawing.Size(296, 26);
            this.txtVaccineName.TabIndex = 1;
            // 
            // txtTotalDoses
            // 
            this.txtTotalDoses.Location = new System.Drawing.Point(733, 284);
            this.txtTotalDoses.Name = "txtTotalDoses";
            this.txtTotalDoses.Size = new System.Drawing.Size(296, 26);
            this.txtTotalDoses.TabIndex = 2;
            // 
            // dtpDueDate
            // 
            this.dtpDueDate.Location = new System.Drawing.Point(718, 372);
            this.dtpDueDate.Name = "dtpDueDate";
            this.dtpDueDate.Size = new System.Drawing.Size(311, 26);
            this.dtpDueDate.TabIndex = 3;
            // 
            // cmbStatus
            // 
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Completed",
            "Pending",
            "Missed"});
            this.cmbStatus.Location = new System.Drawing.Point(735, 448);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(290, 28);
            this.cmbStatus.TabIndex = 4;
            // 
            // btnAddVaccine
            // 
            this.btnAddVaccine.BackColor = System.Drawing.Color.LightBlue;
            this.btnAddVaccine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddVaccine.Location = new System.Drawing.Point(332, 512);
            this.btnAddVaccine.Name = "btnAddVaccine";
            this.btnAddVaccine.Size = new System.Drawing.Size(210, 58);
            this.btnAddVaccine.TabIndex = 5;
            this.btnAddVaccine.Text = "AddVaccine";
            this.btnAddVaccine.UseVisualStyleBackColor = false;
            this.btnAddVaccine.Click += new System.EventHandler(this.btnAddVaccine_Click);
            // 
            // btnUpdateVaccine
            // 
            this.btnUpdateVaccine.BackColor = System.Drawing.Color.LightBlue;
            this.btnUpdateVaccine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateVaccine.Location = new System.Drawing.Point(621, 512);
            this.btnUpdateVaccine.Name = "btnUpdateVaccine";
            this.btnUpdateVaccine.Size = new System.Drawing.Size(210, 58);
            this.btnUpdateVaccine.TabIndex = 6;
            this.btnUpdateVaccine.Text = "Update";
            this.btnUpdateVaccine.UseVisualStyleBackColor = false;
            this.btnUpdateVaccine.Click += new System.EventHandler(this.btnUpdateVaccine_Click);
            // 
            // dgvVaccination
            // 
            this.dgvVaccination.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVaccination.Location = new System.Drawing.Point(60, 111);
            this.dgvVaccination.Name = "dgvVaccination";
            this.dgvVaccination.RowHeadersWidth = 62;
            this.dgvVaccination.RowTemplate.Height = 28;
            this.dgvVaccination.Size = new System.Drawing.Size(409, 287);
            this.dgvVaccination.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(521, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "Family Member Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(562, 193);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Vaccine Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(542, 285);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(169, 25);
            this.label3.TabIndex = 10;
            this.label3.Text = "Complete Dosage";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(576, 372);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 25);
            this.label4.TabIndex = 11;
            this.label4.Text = "Due Date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(593, 448);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 25);
            this.label5.TabIndex = 12;
            this.label5.Text = "Status";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.LightBlue;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(912, 520);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(140, 42);
            this.btnBack.TabIndex = 13;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // VaccinationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1092, 582);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvVaccination);
            this.Controls.Add(this.btnUpdateVaccine);
            this.Controls.Add(this.btnAddVaccine);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.dtpDueDate);
            this.Controls.Add(this.txtTotalDoses);
            this.Controls.Add(this.txtVaccineName);
            this.Controls.Add(this.cmbFamilyMember);
            this.Name = "VaccinationForm";
            this.Text = "VaccinationForm";
            this.Load += new System.EventHandler(this.VaccinationForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVaccination)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbFamilyMember;
        private System.Windows.Forms.TextBox txtVaccineName;
        private System.Windows.Forms.TextBox txtTotalDoses;
        private System.Windows.Forms.DateTimePicker dtpDueDate;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Button btnAddVaccine;
        private System.Windows.Forms.Button btnUpdateVaccine;
        private System.Windows.Forms.DataGridView dgvVaccination;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnBack;
    }
}