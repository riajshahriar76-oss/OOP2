﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Health
{
    public partial class SignUpForm : Form
    {
        public SignUpForm()
        {
            InitializeComponent();
            SetupControls();
        }

        private void SetupControls()
        {
            // placeholders
            SetPlaceholder(txtName, "Full Name");
            SetPlaceholder(txtEmailOrPhone, "Mobile number or Email");
            SetPlaceholder(txtPassword, "New Password");
            txtPassword.UseSystemPasswordChar = false;

            // gender combo
            cmbGender.Items.Clear();
            cmbGender.Items.AddRange(new string[] { "Male", "Female", "Other" });
            cmbGender.SelectedIndex = 0;
        }

        private void SetPlaceholder(TextBox t, string placeholder)
        {
            t.Text = placeholder;
            t.ForeColor = Color.Gray;

            t.Enter += (s, e) =>
            {
                if (t.Text == placeholder)
                {
                    t.Text = "";
                    t.ForeColor = Color.Black;
                    if (t == txtPassword) txtPassword.UseSystemPasswordChar = true;
                }
            };

            t.Leave += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(t.Text))
                {
                    t.ForeColor = Color.Gray;
                    t.Text = placeholder;
                    if (t == txtPassword) txtPassword.UseSystemPasswordChar = false;
                }
            };
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string emailOrPhone = txtEmailOrPhone.Text.Trim();  // Text from input field
            string password = txtPassword.Text.Trim();
            DateTime dob = dtpDOB.Value.Date;
            string gender = cmbGender.SelectedItem?.ToString() ?? "Other";

            // Ensure the email/phone is not using the placeholder text
            if (emailOrPhone == "Mobile number or Email")
            {
                MessageBox.Show("Please enter a valid email or phone number.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validate required fields
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(emailOrPhone) || string.IsNullOrEmpty(password) ||
                name == "Full Name" || emailOrPhone == "Mobile number or Email" || password == "New Password")
            {
                MessageBox.Show("Please fill all required fields.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = DatabaseHelper.GetConnection()) // Ensure connection is working
                {
                    // Check if the email or phone already exists
                    string checkSql = "SELECT COUNT(*) FROM Users WHERE Email = @Email OR Phone = @Phone";
                    using (var cmd = new SqlCommand(checkSql, conn))
                    {
                        cmd.Parameters.AddWithValue("@Email", emailOrPhone);
                        cmd.Parameters.AddWithValue("@Phone", emailOrPhone);
                        int existing = (int)cmd.ExecuteScalar();

                        if (existing > 0)
                        {
                            MessageBox.Show("This email/phone is already registered. Please use a different one.", "Duplicate Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Insert the new user into the Users table
                    string sql = "INSERT INTO Users (FullName, Phone, Email, Password, DOB, Gender, Role) " +
                                 "VALUES (@FullName, @Phone, @Email, @Password, @DOB, @Gender, 'User')";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        string phone = null, email = null;

                        // Assign the email/phone to the correct field
                        if (emailOrPhone.Contains("@"))
                            email = emailOrPhone;  // It's an email
                        else
                            phone = emailOrPhone;  // It's a phone number

                        cmd.Parameters.AddWithValue("@FullName", name);
                        cmd.Parameters.AddWithValue("@Phone", (object)phone ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Email", (object)email ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Password", password);
                        cmd.Parameters.AddWithValue("@DOB", dob);
                        cmd.Parameters.AddWithValue("@Gender", gender);

                        // Execute the query
                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Account created. Please login.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            var login = new LoginForm();
                            login.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Sign up failed. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show("Database error: " + sqlex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        // Check if the email or phone already exists in the database
        private bool IsEmailOrPhoneExist(string email, string phone)
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = "SELECT COUNT(*) FROM Users WHERE Email = @Email OR Phone = @Phone";
                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@Email", email ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@Phone", phone ?? (object)DBNull.Value);

                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        return count > 0;  // Return true if email/phone exists, else false
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking email/phone: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void btnBackToLogin_Click(object sender, EventArgs e)
        {
            var login = new LoginForm();
            login.Show();
            this.Hide();
        }

        private void SignUpForm_Load(object sender, EventArgs e)
        {
        }
    }
}
