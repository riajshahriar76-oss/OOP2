﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Health
{
    public static class Session
    {
        // Static properties to store logged-in user information
        public static int UserId { get; set; }      // Store the logged-in user's ID
        public static string UserName { get; set; }  // Store the logged-in user's Name
        public static string UserRole { get; set; }  // Store the logged-in user's Role (e.g., "Admin", "User")
    }
}
