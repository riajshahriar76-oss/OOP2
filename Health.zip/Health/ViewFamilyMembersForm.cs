﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Health
{
    public partial class ViewFamilyMembersForm : Form
    {
        public ViewFamilyMembersForm()
        {
            InitializeComponent();  // This will initialize the controls including dgvFamilyMembers
        }

        // This method is called when the form loads
        private void ViewFamilyMembersForm_Load(object sender, EventArgs e)
        {
            LoadFamilyMembers();  // Load family members into the DataGridView
        }

        // Method to load family members data into the DataGridView
        private void LoadFamilyMembers()
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    // SQL query to fetch family members for the logged-in user
                    string sql = "SELECT FamilyMemberID, Name, Relation, Gender, DOB, BloodGroup FROM FamilyMember WHERE UserID = @uid";
                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@uid", Session.UserId);  // Fetch family members for the logged-in user

                        using (var reader = cmd.ExecuteReader())
                        {
                            // Create a DataTable to hold the data
                            DataTable dt = new DataTable();
                            dt.Load(reader);  // Load the data from the database into the DataTable

                            // Bind the DataTable to the DataGridView
                            dgvFamilyMembers.DataSource = dt;  // This will display the family members in the DataGridView

                            // Optionally, customize column headers (if needed)
                            dgvFamilyMembers.Columns["FamilyMemberID"].Visible = false; // Hide the ID column
                            dgvFamilyMembers.Columns["Name"].HeaderText = "Family Member Name";
                            dgvFamilyMembers.Columns["Relation"].HeaderText = "Relation";
                            dgvFamilyMembers.Columns["Gender"].HeaderText = "Gender";
                            dgvFamilyMembers.Columns["DOB"].HeaderText = "Date of Birth";
                            dgvFamilyMembers.Columns["BloodGroup"].HeaderText = "Blood Group";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading family members: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            DashboardForm dashboardForm = new DashboardForm();

            // Show the DashboardForm
            dashboardForm.Show();

            // Hide the current ViewFamilyMembersForm
            this.Hide();
        }

        private void btnAddFamilyMember_Click_Click(object sender, EventArgs e)
        {
            var AddFamilyMember1 = new AddFamilyMember();
            AddFamilyMember1.Show();
            this.Hide();
        }

        /* private void btnUpdate_Click(object sender, EventArgs e)
         {
             // Get the FamilyMemberID from the DataGridView row (you can use your own column index)
             int familyMemberId = Convert.ToInt32(dgvFamilyMembers.SelectedRows[0].Cells["FamilyMemberID"].Value);

             // Open the Edit Family Member form with the selected FamilyMemberID
             EditFamilyMemberForm editForm = new EditFamilyMemberForm();
             editForm.Show();
             this.Hide();  // Hide the current form to avoid multiple open forms
         }*/
        private void dgvFamilyMembers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Ensure the user clicked a valid row
            if (e.RowIndex >= 0)
            {
                // Get the FamilyMemberID from the DataGridView row
                int familyMemberId = Convert.ToInt32(dgvFamilyMembers.Rows[e.RowIndex].Cells["FamilyMemberID"].Value);

                // Optionally, highlight or show the selected member's details
                // Pass the FamilyMemberID to remove or display in form fields
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Get the selected family member's ID
            int selectedFamilyMemberId = GetSelectedFamilyMemberId();  // Implement this function to get the selected member's ID

            if (selectedFamilyMemberId == -1)
            {
                MessageBox.Show("Please select a family member to remove.", "No selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Confirm before removing
            var confirm = MessageBox.Show("Are you sure you want to remove this family member?", "Confirm Removal", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                // Remove from database
                RemoveFamilyMember(selectedFamilyMemberId);
            }
        }

        // Function to get the selected family member's ID
        private int GetSelectedFamilyMemberId()
        {
            // Check if any row is selected
            if (dgvFamilyMembers.SelectedRows.Count > 0)
            {
                // Get the FamilyMemberID from the selected row
                int familyMemberId = Convert.ToInt32(dgvFamilyMembers.SelectedRows[0].Cells["FamilyMemberID"].Value);
                return familyMemberId;
            }
            return -1;  // Return -1 if no row is selected
        }

        // Function to delete the selected family member
        private void RemoveFamilyMember(int familyMemberId)
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = "DELETE FROM FamilyMember WHERE FamilyMemberID = @familyMemberId AND UserID = @userId";
                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@familyMemberId", familyMemberId);
                        cmd.Parameters.AddWithValue("@userId", Session.UserId);  // Ensure only logged-in user can remove their own family members

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Family member removed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadFamilyMembers();  // Refresh the DataGridView to reflect changes
                        }
                        else
                        {
                            MessageBox.Show("Error removing family member.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing family member: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchValue = txtSearch.Text.Trim();  // txtSearch is your search textbox

            if (string.IsNullOrWhiteSpace(searchValue))
            {
                MessageBox.Show("Please enter a search term.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = @"SELECT FamilyMemberID, Name, Relation, Gender, DOB, BloodGroup 
                     FROM FamilyMember
                     WHERE UserID = @userId AND (
                        CAST(FamilyMemberID AS NVARCHAR) LIKE @searchTerm OR
                        Name LIKE @searchTerm OR
                        Relation LIKE @searchTerm OR
                        Gender LIKE @searchTerm OR
                        CAST(DOB AS NVARCHAR) LIKE @searchTerm OR
                        BloodGroup LIKE @searchTerm
                     )";

            using (SqlConnection connection = new SqlConnection(DatabaseHelper.ConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@userId", Session.UserId); // Only show current user's family members
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchValue + "%");

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);

                    dgvFamilyMembers.DataSource = dataTable;  // dgvFamilyMembers is your DataGridView

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No matching family members found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

