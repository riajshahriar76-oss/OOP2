﻿namespace Health
{
    partial class MedicationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MedicationForm));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbFamilyMember = new System.Windows.Forms.ComboBox();
            this.txtMedName = new System.Windows.Forms.TextBox();
            this.txtDosage = new System.Windows.Forms.TextBox();
            this.txtFrequency = new System.Windows.Forms.TextBox();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.nudStock = new System.Windows.Forms.NumericUpDown();
            this.dtpExpiryDate = new System.Windows.Forms.DateTimePicker();
            this.btnAddMedication = new System.Windows.Forms.Button();
            this.btnUpdateMedication = new System.Windows.Forms.Button();
            this.btnDeleteMedication = new System.Windows.Forms.Button();
            this.btnRefreshMedication = new System.Windows.Forms.Button();
            this.dgvMedications = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudStock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMedications)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(359, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Member";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(363, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Member Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(380, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Dosage";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(380, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Frequency";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(386, 280);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Start Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(386, 338);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "End date";
            // 
            // cmbFamilyMember
            // 
            this.cmbFamilyMember.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFamilyMember.FormattingEnabled = true;
            this.cmbFamilyMember.Location = new System.Drawing.Point(519, 59);
            this.cmbFamilyMember.Name = "cmbFamilyMember";
            this.cmbFamilyMember.Size = new System.Drawing.Size(214, 28);
            this.cmbFamilyMember.TabIndex = 6;
            // 
            // txtMedName
            // 
            this.txtMedName.Location = new System.Drawing.Point(521, 109);
            this.txtMedName.Name = "txtMedName";
            this.txtMedName.Size = new System.Drawing.Size(212, 26);
            this.txtMedName.TabIndex = 7;
            // 
            // txtDosage
            // 
            this.txtDosage.Location = new System.Drawing.Point(519, 165);
            this.txtDosage.Name = "txtDosage";
            this.txtDosage.Size = new System.Drawing.Size(212, 26);
            this.txtDosage.TabIndex = 8;
            // 
            // txtFrequency
            // 
            this.txtFrequency.Location = new System.Drawing.Point(521, 218);
            this.txtFrequency.Name = "txtFrequency";
            this.txtFrequency.Size = new System.Drawing.Size(212, 26);
            this.txtFrequency.TabIndex = 9;
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Location = new System.Drawing.Point(523, 280);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(227, 26);
            this.dtpStartDate.TabIndex = 10;
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.Location = new System.Drawing.Point(521, 337);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(200, 26);
            this.dtpEndDate.TabIndex = 21;
            // 
            // nudStock
            // 
            this.nudStock.Location = new System.Drawing.Point(524, 416);
            this.nudStock.Name = "nudStock";
            this.nudStock.Size = new System.Drawing.Size(253, 26);
            this.nudStock.TabIndex = 12;
            // 
            // dtpExpiryDate
            // 
            this.dtpExpiryDate.Location = new System.Drawing.Point(524, 470);
            this.dtpExpiryDate.Name = "dtpExpiryDate";
            this.dtpExpiryDate.Size = new System.Drawing.Size(227, 26);
            this.dtpExpiryDate.TabIndex = 13;
            // 
            // btnAddMedication
            // 
            this.btnAddMedication.BackColor = System.Drawing.Color.LightBlue;
            this.btnAddMedication.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddMedication.Location = new System.Drawing.Point(835, 124);
            this.btnAddMedication.Name = "btnAddMedication";
            this.btnAddMedication.Size = new System.Drawing.Size(250, 54);
            this.btnAddMedication.TabIndex = 14;
            this.btnAddMedication.Text = "Add";
            this.btnAddMedication.UseVisualStyleBackColor = false;
            this.btnAddMedication.Click += new System.EventHandler(this.btnAddMedication_Click);
            // 
            // btnUpdateMedication
            // 
            this.btnUpdateMedication.BackColor = System.Drawing.Color.LightBlue;
            this.btnUpdateMedication.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateMedication.Location = new System.Drawing.Point(835, 218);
            this.btnUpdateMedication.Name = "btnUpdateMedication";
            this.btnUpdateMedication.Size = new System.Drawing.Size(250, 54);
            this.btnUpdateMedication.TabIndex = 15;
            this.btnUpdateMedication.Text = "Update ";
            this.btnUpdateMedication.UseVisualStyleBackColor = false;
            this.btnUpdateMedication.Click += new System.EventHandler(this.btnUpdateMedication_Click);
            // 
            // btnDeleteMedication
            // 
            this.btnDeleteMedication.BackColor = System.Drawing.Color.LightBlue;
            this.btnDeleteMedication.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteMedication.Location = new System.Drawing.Point(835, 325);
            this.btnDeleteMedication.Name = "btnDeleteMedication";
            this.btnDeleteMedication.Size = new System.Drawing.Size(250, 54);
            this.btnDeleteMedication.TabIndex = 16;
            this.btnDeleteMedication.Text = "Delete";
            this.btnDeleteMedication.UseVisualStyleBackColor = false;
            this.btnDeleteMedication.Click += new System.EventHandler(this.btnDeleteMedication_Click);
            // 
            // btnRefreshMedication
            // 
            this.btnRefreshMedication.BackColor = System.Drawing.Color.LightBlue;
            this.btnRefreshMedication.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshMedication.Location = new System.Drawing.Point(835, 414);
            this.btnRefreshMedication.Name = "btnRefreshMedication";
            this.btnRefreshMedication.Size = new System.Drawing.Size(250, 54);
            this.btnRefreshMedication.TabIndex = 17;
            this.btnRefreshMedication.Text = "Refresh";
            this.btnRefreshMedication.UseVisualStyleBackColor = false;
            this.btnRefreshMedication.Click += new System.EventHandler(this.btnRefreshMedication_Click);
            // 
            // dgvMedications
            // 
            this.dgvMedications.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dgvMedications.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMedications.Location = new System.Drawing.Point(18, 124);
            this.dgvMedications.Name = "dgvMedications";
            this.dgvMedications.RowHeadersWidth = 62;
            this.dgvMedications.RowTemplate.Height = 28;
            this.dgvMedications.Size = new System.Drawing.Size(339, 371);
            this.dgvMedications.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(364, 414);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(140, 25);
            this.label7.TabIndex = 19;
            this.label7.Text = "Stock Quantity";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(380, 471);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 25);
            this.label8.TabIndex = 20;
            this.label8.Text = "Expire Date";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.LightBlue;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(902, 500);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(127, 54);
            this.btnBack.TabIndex = 22;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // MedicationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1134, 589);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dgvMedications);
            this.Controls.Add(this.btnRefreshMedication);
            this.Controls.Add(this.btnDeleteMedication);
            this.Controls.Add(this.btnUpdateMedication);
            this.Controls.Add(this.btnAddMedication);
            this.Controls.Add(this.dtpExpiryDate);
            this.Controls.Add(this.nudStock);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.txtFrequency);
            this.Controls.Add(this.txtDosage);
            this.Controls.Add(this.txtMedName);
            this.Controls.Add(this.cmbFamilyMember);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "MedicationForm";
            this.Text = "MedicationForm";
            this.Load += new System.EventHandler(this.MedicationForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudStock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMedications)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbFamilyMember;
        private System.Windows.Forms.TextBox txtMedName;
        private System.Windows.Forms.TextBox txtDosage;
        private System.Windows.Forms.TextBox txtFrequency;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.NumericUpDown nudStock;
        private System.Windows.Forms.DateTimePicker dtpExpiryDate;
        private System.Windows.Forms.Button btnAddMedication;
        private System.Windows.Forms.Button btnUpdateMedication;
        private System.Windows.Forms.Button btnDeleteMedication;
        private System.Windows.Forms.Button btnRefreshMedication;
        private System.Windows.Forms.DataGridView dgvMedications;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnBack;
    }
}