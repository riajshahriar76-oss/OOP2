﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Health
{
    public partial class VaccinationForm : Form
    {
        public VaccinationForm()
        {
            InitializeComponent();
            LoadFamilyMembers();  // Load family members when form is opened
            LoadVaccinationData();  // Load vaccination data into the DataGridView
        }

        // Method to load family members into ComboBox
        private void LoadFamilyMembers()
        {
            try
            {
                cmbFamilyMember.Items.Clear();  // Clear previous items in ComboBox

                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = "SELECT FamilyMemberID, Name FROM FamilyMember WHERE UserID = @uid";
                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@uid", Session.UserId);  // Get the current logged-in user's family members

                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                cmbFamilyMember.Items.Add(new
                                {
                                    Text = reader["Name"].ToString(),
                                    Value = reader["FamilyMemberID"].ToString()
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading family members: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Method to load vaccination data into DataGridView
        private void LoadVaccinationData()
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = "SELECT v.VaccineID, v.VName, v.DueDate, v.TotalDoses, v.CompletedDoses, v.Status, fm.Name as FamilyMemberName " +
                                 "FROM Vaccine v " +
                                 "JOIN FamilyMember fm ON v.FamilyMemberID = fm.FamilyMemberID " +
                                 "WHERE fm.UserID = @uid";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@uid", Session.UserId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            DataTable dt = new DataTable();
                            dt.Load(reader);
                            dgvVaccination.DataSource = dt;  // Bind the data to DataGridView
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading vaccination data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Button to Add a new Vaccine record
        private void btnAddVaccine_Click(object sender, EventArgs e)
        {
            if (cmbFamilyMember.SelectedIndex == -1 || string.IsNullOrWhiteSpace(txtVaccineName.Text) ||
                string.IsNullOrWhiteSpace(txtTotalDoses.Text) || dtpDueDate.Value == null || cmbStatus.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill all fields.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int familyMemberId = Convert.ToInt32(((dynamic)cmbFamilyMember.SelectedItem).Value);
            string vaccineName = txtVaccineName.Text.Trim();
            int totalDoses = Convert.ToInt32(txtTotalDoses.Text);
            DateTime dueDate = dtpDueDate.Value;
            string status = cmbStatus.SelectedItem.ToString();

            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = "INSERT INTO Vaccine (FamilyMemberID, VName, DueDate, TotalDoses, Status) " +
                                 "VALUES (@familyMemberId, @vaccineName, @dueDate, @totalDoses, @status)";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@familyMemberId", familyMemberId);
                        cmd.Parameters.AddWithValue("@vaccineName", vaccineName);
                        cmd.Parameters.AddWithValue("@dueDate", dueDate);
                        cmd.Parameters.AddWithValue("@totalDoses", totalDoses);
                        cmd.Parameters.AddWithValue("@status", status);

                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Vaccine added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadVaccinationData();  // Refresh the DataGridView with updated data
                        }
                        else
                        {
                            MessageBox.Show("Error adding vaccine record.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding vaccine: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Button to Update Vaccine status or details
        private void btnUpdateVaccine_Click(object sender, EventArgs e)
        {
            if (cmbFamilyMember.SelectedIndex == -1 || string.IsNullOrWhiteSpace(txtVaccineName.Text))
            {
                MessageBox.Show("Please select a family member and vaccine.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int familyMemberId = Convert.ToInt32(((dynamic)cmbFamilyMember.SelectedItem).Value);
            string vaccineName = txtVaccineName.Text.Trim();
            string status = cmbStatus.SelectedItem.ToString();

            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = "UPDATE Vaccine SET Status = @status WHERE FamilyMemberID = @familyMemberId AND VName = @vaccineName";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@familyMemberId", familyMemberId);
                        cmd.Parameters.AddWithValue("@vaccineName", vaccineName);
                        cmd.Parameters.AddWithValue("@status", status);

                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Vaccine record updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadVaccinationData();  // Refresh the DataGridView with updated data
                        }
                        else
                        {
                            MessageBox.Show("Error updating vaccine record.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating vaccine: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void VaccinationForm_Load(object sender, EventArgs e)
        {
            LoadFamilyMembers();  // Load family members into ComboBox
            LoadVaccinationData();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            DashboardForm dashboardForm = new DashboardForm();

            // Show the DashboardForm
            dashboardForm.Show();

            // Hide the current ViewFamilyMembersForm
            this.Hide();
        }
    }
    }

