﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;

namespace Health
{
    public partial class AddFamilyMember : Form
    {
        public AddFamilyMember()
        {
            InitializeComponent();
        }

        private void btnAddFamilyMember_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string relation = txtRelation.Text.Trim();
            string gender = cmbGender.SelectedItem?.ToString() ?? "Other";
            DateTime dob = dtpDOB.Value.Date;
            string bloodGroup = txtBloodGroup.Text.Trim();

            // Validation
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter a name.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = "INSERT INTO FamilyMember (UserID, Name, Relation, Gender, DOB, BloodGroup) " +
                                 "VALUES (@uid, @name, @relation, @gender, @dob, @bloodGroup)";
                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@uid", Session.UserId);  // Use logged-in user's ID from Session
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@relation", relation);
                        cmd.Parameters.AddWithValue("@gender", gender);
                        cmd.Parameters.AddWithValue("@dob", dob);
                        cmd.Parameters.AddWithValue("@bloodGroup", string.IsNullOrWhiteSpace(bloodGroup) ? DBNull.Value : (object)bloodGroup);

                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Family member added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Optionally, refresh the family members list in the dashboard or navigate to another form
                            // This could be done by calling a method like LoadFamilyMembers() from the DashboardForm
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding family member: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            ViewFamilyMembersForm View = new ViewFamilyMembersForm();

            // Show the DashboardForm
            View.Show();

            // Hide the current ViewFamilyMembersForm
            this.Hide();
        }
    }
}
