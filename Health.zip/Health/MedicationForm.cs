﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Health
{
    public partial class MedicationForm : Form
    {
        private int _userId;

        public MedicationForm(int userId)
        {
            InitializeComponent();
            _userId = userId;
        }

        // Form Load event to load family members into ComboBox
        private void MedicationForm_Load(object sender, EventArgs e)
        {
            LoadFamilyMembers();  // Populate family members in the ComboBox
        }

        private void LoadFamilyMembers()
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = "SELECT FamilyMemberID, Name FROM FamilyMember WHERE UserID = @uid ORDER BY Name";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@uid", _userId); // Ensure _userId is passed correctly
                    SqlDataReader reader = cmd.ExecuteReader();

                    cmbFamilyMember.Items.Clear();  // Clear any existing items
                    while (reader.Read())
                    {
                        cmbFamilyMember.Items.Add(new
                        {
                            Text = reader["Name"].ToString(),
                            Value = reader["FamilyMemberID"]
                        });
                    }

                    cmbFamilyMember.DisplayMember = "Text"; // Display member name
                    cmbFamilyMember.ValueMember = "Value"; // Use FamilyMemberID as the value

                    if (cmbFamilyMember.Items.Count > 0)
                    {
                        cmbFamilyMember.SelectedIndex = 0;  // Select the first item by default
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading family members: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        // Load medications when a family member is selected from ComboBox
        private void cmbFamilyMember_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbFamilyMember.SelectedValue != null)
            {
                int selectedFamilyMemberId = Convert.ToInt32(cmbFamilyMember.SelectedValue);  // Get the selected FamilyMemberID
                LoadMedicationData(selectedFamilyMemberId);  // Pass familyMemberId to the method
            }
        }




        private void LoadMedicationData(int familyMemberId)
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = @"SELECT 
                            m.MedicationID,
                            m.MedName,
                            m.Dosage,
                            m.Frequency,
                            m.StartDate,
                            m.EndDate,
                            m.StockQuantity,
                            m.ExpiryDate,
                            fm.Name AS FamilyMemberName
                        FROM Medication m 
                        INNER JOIN FamilyMember fm ON m.FamilyMemberID = fm.FamilyMemberID
                        WHERE m.FamilyMemberID = @fmId
                        ORDER BY m.CreatedAt DESC";

                    SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                    adapter.SelectCommand.Parameters.AddWithValue("@fmId", familyMemberId);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvMedications.DataSource = dt;

                    // Hide unnecessary columns
                    dgvMedications.Columns["MedicationID"].Visible = false;
                    dgvMedications.Columns["FamilyMemberID"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading medications: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnAddMedication_Click(object sender, EventArgs e)
        {
            // Get the FamilyMemberID from ComboBox
            int familyMemberId = Convert.ToInt32(cmbFamilyMember.SelectedValue);

            // Check if FamilyMemberID is valid (not 0)
            if (familyMemberId == 0)
            {
                MessageBox.Show("Please select a valid family member.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;  // Exit the method if no family member is selected
            }

            // Debugging line to check if the correct FamilyMemberID is selected
            MessageBox.Show("Selected FamilyMemberID: " + familyMemberId);

            // Get other medication details
            string medName = txtMedName.Text.Trim();
            string dosage = txtDosage.Text.Trim();
            string frequency = txtFrequency.Text.Trim();
            DateTime startDate = dtpStartDate.Value.Date;
            DateTime? endDate = dtpEndDate.Checked ? dtpEndDate.Value.Date : (DateTime?)null;
            int stockQuantity = (int)nudStock.Value;
            DateTime expiryDate = dtpExpiryDate.Value.Date;

            // Validate input
            if (string.IsNullOrEmpty(medName) || string.IsNullOrEmpty(dosage) || string.IsNullOrEmpty(frequency))
            {
                MessageBox.Show("Please fill all required fields.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = "INSERT INTO Medication (FamilyMemberID, MedName, Dosage, Frequency, StartDate, EndDate, StockQuantity, ExpiryDate) " +
                                 "VALUES (@fmId, @medName, @dosage, @frequency, @startDate, @endDate, @stockQuantity, @expiryDate)";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@fmId", familyMemberId);  // Use the correct FamilyMemberID
                        cmd.Parameters.AddWithValue("@medName", medName);
                        cmd.Parameters.AddWithValue("@dosage", dosage);
                        cmd.Parameters.AddWithValue("@frequency", frequency);
                        cmd.Parameters.AddWithValue("@startDate", startDate);
                        cmd.Parameters.AddWithValue("@endDate", (object)endDate ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@stockQuantity", stockQuantity);
                        cmd.Parameters.AddWithValue("@expiryDate", expiryDate);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Medication added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadMedicationData(familyMemberId);  // Refresh grid after adding
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding medication: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        private void btnUpdateMedication_Click(object sender, EventArgs e)
        {
            // Check if a row is selected in the DataGridView
            if (dgvMedications.CurrentRow == null)
            {
                MessageBox.Show("Please select a medication to update.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit if no row is selected
            }

            // Get MedicationID from the selected row
            int medicationId = Convert.ToInt32(dgvMedications.CurrentRow.Cells["MedicationID"].Value);

            // Get other input data
            string medName = txtMedName.Text.Trim();
            string dosage = txtDosage.Text.Trim();
            string frequency = txtFrequency.Text.Trim();
            DateTime startDate = dtpStartDate.Value.Date;
            DateTime? endDate = dtpEndDate.Checked ? dtpEndDate.Value.Date : (DateTime?)null;
            int stockQuantity = (int)nudStock.Value;
            DateTime expiryDate = dtpExpiryDate.Value.Date;

            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    // SQL query to update medication
                    string sql = @"UPDATE Medication SET MedName = @medName, Dosage = @dosage, Frequency = @frequency, 
                           StartDate = @startDate, EndDate = @endDate, StockQuantity = @stockQuantity, 
                           ExpiryDate = @expiryDate WHERE MedicationID = @medId";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@medName", medName);
                        cmd.Parameters.AddWithValue("@dosage", dosage);
                        cmd.Parameters.AddWithValue("@frequency", frequency);
                        cmd.Parameters.AddWithValue("@startDate", startDate);
                        cmd.Parameters.AddWithValue("@endDate", (object)endDate ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@stockQuantity", stockQuantity);
                        cmd.Parameters.AddWithValue("@expiryDate", expiryDate);
                        cmd.Parameters.AddWithValue("@medId", medicationId); // Use MedicationID of the selected row
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Medication updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadMedicationData(Convert.ToInt32(cmbFamilyMember.SelectedValue));  // Refresh grid
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnDeleteMedication_Click(object sender, EventArgs e)
        {
            int medicationId = Convert.ToInt32(dgvMedications.CurrentRow.Cells["MedicationID"].Value);
            var confirm = MessageBox.Show("Delete selected medication?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm == DialogResult.Yes)
            {
                try
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        string sql = "DELETE FROM Medication WHERE MedicationID = @medId";
                        using (var cmd = new SqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@medId", medicationId);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Medication deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadMedicationData();  // Refresh grid
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Delete failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadMedicationData()
        {
            throw new NotImplementedException();
        }

        private void btnRefreshMedication_Click(object sender, EventArgs e)
        {
            // Ensure a valid family member is selected
            if (cmbFamilyMember.SelectedValue != null)
            {
                int familyMemberId = Convert.ToInt32(cmbFamilyMember.SelectedValue);  // Get the selected FamilyMemberID
                LoadMedicationData(familyMemberId);  // Pass familyMemberId to the method
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            DashboardForm dashboardForm = new DashboardForm();

            // Show the DashboardForm
            dashboardForm.Show();

            // Hide the current ViewFamilyMembersForm
            this.Hide();
        }
    }
}
