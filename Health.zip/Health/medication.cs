using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Health
{
    public partial class Medication : Form
    {
        // ORIGINAL: Your existing constructor - UNCHANGED
        public Medication()
        {
            InitializeComponent();
            // NEW: Add these lines to load data when form opens
            LoadMedicationData();
            LoadFamilyMembers();
        }

        // NEW: Load medication data into DataGridView
        private void LoadMedicationData()
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = @"SELECT 
                                    m.MedicationID,
                                    m.MedName,
                                    m.Dosage,
                                    m.Frequency,
                                    m.StartDate,
                                    m.EndDate,
                                    m.StockQuantity,
                                    m.ExpiryDate,
                                    fm.Name as FamilyMemberName,
                                    m.FamilyMemberID
                                FROM Medication m 
                                INNER JOIN FamilyMember fm ON m.FamilyMemberID = fm.FamilyMemberID
                                ORDER BY m.CreatedAt DESC";

                    SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading medication data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // NEW: Load family members for reference
        private void LoadFamilyMembers()
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = "SELECT FamilyMemberID, Name FROM FamilyMember ORDER BY Name";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    
                    comboBox1.Items.Clear();
                    while (reader.Read())
                    {
                        comboBox1.Items.Add(new { 
                            Text = reader["Name"].ToString(), 
                            Value = reader["FamilyMemberID"] 
                        });
                    }
                    comboBox1.DisplayMember = "Text";
                    comboBox1.ValueMember = "Value";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading family members: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // NEW: Validation method
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Please enter medication name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(textBox5.Text))
            {
                MessageBox.Show("Please enter Family Member ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.Focus();
                return false;
            }

            if (!int.TryParse(textBox5.Text, out _))
            {
                MessageBox.Show("Family Member ID must be a number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(textBox4.Text) || !int.TryParse(textBox4.Text, out _))
            {
                MessageBox.Show("Please enter a valid quantity.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox4.Focus();
                return false;
            }

            return true;
        }

        // NEW: Clear form method
        private void ClearAllFields()
        {
            textBox1.Text = ""; // Medication Name
            textBox2.Text = ""; // Medication ID
            textBox3.Text = ""; // Dosage
            textBox4.Text = ""; // Quantity
            textBox5.Text = ""; // Family ID
            textBox6.Text = ""; // Frequency
            dateTimePicker1.Value = DateTime.Now;
            dateTimePicker2.Value = DateTime.Now;
            comboBox1.SelectedIndex = -1;
        }

        // NEW: Add medication functionality for Button1
        private void AddMedication()
        {
            if (ValidateInput())
            {
                try
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        string sql = @"INSERT INTO Medication (FamilyMemberID, MedName, Dosage, Frequency, StartDate, EndDate, StockQuantity, ExpiryDate) 
                                     VALUES (@FamilyMemberID, @MedName, @Dosage, @Frequency, @StartDate, @EndDate, @StockQuantity, @ExpiryDate)";
                        
                        SqlCommand cmd = new SqlCommand(sql, conn);
                        cmd.Parameters.AddWithValue("@FamilyMemberID", int.Parse(textBox5.Text));
                        cmd.Parameters.AddWithValue("@MedName", textBox1.Text.Trim());
                        cmd.Parameters.AddWithValue("@Dosage", textBox3.Text.Trim());
                        cmd.Parameters.AddWithValue("@Frequency", textBox6.Text.Trim());
                        cmd.Parameters.AddWithValue("@StartDate", dateTimePicker1.Value.Date);
                        cmd.Parameters.AddWithValue("@EndDate", dateTimePicker1.Value.Date);
                        cmd.Parameters.AddWithValue("@StockQuantity", int.Parse(textBox4.Text));
                        cmd.Parameters.AddWithValue("@ExpiryDate", dateTimePicker2.Value.Date);

                        int result = cmd.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("Medication added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearAllFields();
                            LoadMedicationData();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding medication: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // NEW: Update medication functionality for Button2
        private void UpdateMedication()
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Please select a medication to update.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (ValidateInput())
            {
                try
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        string sql = @"UPDATE Medication SET 
                                     FamilyMemberID = @FamilyMemberID,
                                     MedName = @MedName,
                                     Dosage = @Dosage,
                                     Frequency = @Frequency,
                                     StartDate = @StartDate,
                                     EndDate = @EndDate,
                                     StockQuantity = @StockQuantity,
                                     ExpiryDate = @ExpiryDate
                                     WHERE MedicationID = @MedicationID";
                        
                        SqlCommand cmd = new SqlCommand(sql, conn);
                        cmd.Parameters.AddWithValue("@MedicationID", int.Parse(textBox2.Text));
                        cmd.Parameters.AddWithValue("@FamilyMemberID", int.Parse(textBox5.Text));
                        cmd.Parameters.AddWithValue("@MedName", textBox1.Text.Trim());
                        cmd.Parameters.AddWithValue("@Dosage", textBox3.Text.Trim());
                        cmd.Parameters.AddWithValue("@Frequency", textBox6.Text.Trim());
                        cmd.Parameters.AddWithValue("@StartDate", dateTimePicker1.Value.Date);
                        cmd.Parameters.AddWithValue("@EndDate", dateTimePicker1.Value.Date);
                        cmd.Parameters.AddWithValue("@StockQuantity", int.Parse(textBox4.Text));
                        cmd.Parameters.AddWithValue("@ExpiryDate", dateTimePicker2.Value.Date);

                        int result = cmd.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("Medication updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearAllFields();
                            LoadMedicationData();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating medication: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // NEW: Delete medication functionality for Button3
        private void DeleteMedication()
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Please select a medication to delete.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this medication?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        string deleteMed = "DELETE FROM Medication WHERE MedicationID = @MedicationID";
                        SqlCommand cmdMed = new SqlCommand(deleteMed, conn);
                        cmdMed.Parameters.AddWithValue("@MedicationID", int.Parse(textBox2.Text));
                        
                        int deleteResult = cmdMed.ExecuteNonQuery();
                        if (deleteResult > 0)
                        {
                            MessageBox.Show("Medication deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearAllFields();
                            LoadMedicationData();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting medication: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // NEW: Load selected data from grid
        private void LoadSelectedData(int rowIndex)
        {
            if (rowIndex >= 0)
            {
                try
                {
                    DataGridViewRow row = dataGridView1.Rows[rowIndex];
                    textBox2.Text = row.Cells["MedicationID"].Value?.ToString();
                    textBox1.Text = row.Cells["MedName"].Value?.ToString();
                    textBox3.Text = row.Cells["Dosage"].Value?.ToString();
                    textBox6.Text = row.Cells["Frequency"].Value?.ToString();
                    textBox4.Text = row.Cells["StockQuantity"].Value?.ToString();
                    textBox5.Text = row.Cells["FamilyMemberID"].Value?.ToString();
                    
                    if (DateTime.TryParse(row.Cells["StartDate"].Value?.ToString(), out DateTime startDate))
                        dateTimePicker1.Value = startDate;
                    
                    if (DateTime.TryParse(row.Cells["ExpiryDate"].Value?.ToString(), out DateTime expiryDate))
                        dateTimePicker2.Value = expiryDate;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading selected data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // ORIGINAL: Your existing methods - UNCHANGED
        private void label3_Click(object sender, EventArgs e)
        {
            // Your original code stays here
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            // Your original code stays here
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // Your original code stays here
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            // Your original code stays here
        }

        private void label4_Click(object sender, EventArgs e)
        {
            // Your original code stays here
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            // Your original code stays here
        }

        private void label6_Click(object sender, EventArgs e)
        {
            // Your original code stays here
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Your original code stays here
            
            // NEW: Add this line to call update functionality
            UpdateMedication();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Your original code stays here
            
            // NEW: Add this line to load selected data
            LoadSelectedData(e.RowIndex);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Your original code stays here
            
            // NEW: Add this line to clear form
            ClearAllFields();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Your original code stays here
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Your original code stays here
        }

        private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
        {
            // Your original code stays here
        }

        // NEW: Add these methods for Button1 and Button3
        private void button1_Click(object sender, EventArgs e)
        {
            // Call add functionality
            AddMedication();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Call delete functionality
            DeleteMedication();
        }
    }
}