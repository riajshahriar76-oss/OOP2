﻿namespace Health
{
    partial class DashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardForm));
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblUserInfo = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.ViewFamilyMembersForm = new System.Windows.Forms.Button();
            this.btnShowProfile = new System.Windows.Forms.Button();
            this.btnBloodDonation = new System.Windows.Forms.Button();
            this.btnVaccination = new System.Windows.Forms.Button();
            this.btnMedication = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.Location = new System.Drawing.Point(317, 35);
            this.lblWelcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(598, 40);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome to Family Health System";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblWelcome.Click += new System.EventHandler(this.lblWelcome_Click);
            // 
            // lblUserInfo
            // 
            this.lblUserInfo.AutoSize = true;
            this.lblUserInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserInfo.Location = new System.Drawing.Point(429, 97);
            this.lblUserInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserInfo.Name = "lblUserInfo";
            this.lblUserInfo.Size = new System.Drawing.Size(296, 29);
            this.lblUserInfo.TabIndex = 1;
            this.lblUserInfo.Text = "Logged in as: [User Email]";
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(999, 45);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(112, 45);
            this.btnLogout.TabIndex = 2;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // ViewFamilyMembersForm
            // 
            this.ViewFamilyMembersForm.BackColor = System.Drawing.Color.LightBlue;
            this.ViewFamilyMembersForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewFamilyMembersForm.Location = new System.Drawing.Point(434, 215);
            this.ViewFamilyMembersForm.Name = "ViewFamilyMembersForm";
            this.ViewFamilyMembersForm.Size = new System.Drawing.Size(313, 56);
            this.ViewFamilyMembersForm.TabIndex = 4;
            this.ViewFamilyMembersForm.Text = "View All Family Members";
            this.ViewFamilyMembersForm.UseVisualStyleBackColor = false;
            this.ViewFamilyMembersForm.Click += new System.EventHandler(this.ViewFamilyMembersForm_Click);
            // 
            // btnShowProfile
            // 
            this.btnShowProfile.BackColor = System.Drawing.Color.LightBlue;
            this.btnShowProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowProfile.Location = new System.Drawing.Point(129, 215);
            this.btnShowProfile.Name = "btnShowProfile";
            this.btnShowProfile.Size = new System.Drawing.Size(187, 56);
            this.btnShowProfile.TabIndex = 5;
            this.btnShowProfile.Text = "Show Profile";
            this.btnShowProfile.UseVisualStyleBackColor = false;
            this.btnShowProfile.Click += new System.EventHandler(this.btnShowProfile_Click);
            // 
            // btnBloodDonation
            // 
            this.btnBloodDonation.BackColor = System.Drawing.Color.LightBlue;
            this.btnBloodDonation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBloodDonation.Location = new System.Drawing.Point(250, 359);
            this.btnBloodDonation.Name = "btnBloodDonation";
            this.btnBloodDonation.Size = new System.Drawing.Size(266, 58);
            this.btnBloodDonation.TabIndex = 6;
            this.btnBloodDonation.Text = "Blood Donation";
            this.btnBloodDonation.UseVisualStyleBackColor = false;
            this.btnBloodDonation.Click += new System.EventHandler(this.btnBloodDonation_Click);
            // 
            // btnVaccination
            // 
            this.btnVaccination.BackColor = System.Drawing.Color.LightBlue;
            this.btnVaccination.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVaccination.Location = new System.Drawing.Point(654, 359);
            this.btnVaccination.Name = "btnVaccination";
            this.btnVaccination.Size = new System.Drawing.Size(206, 58);
            this.btnVaccination.TabIndex = 7;
            this.btnVaccination.Text = "Vaccination";
            this.btnVaccination.UseVisualStyleBackColor = false;
            this.btnVaccination.Click += new System.EventHandler(this.btnVaccination_Click);
            // 
            // btnMedication
            // 
            this.btnMedication.BackColor = System.Drawing.Color.LightBlue;
            this.btnMedication.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedication.Location = new System.Drawing.Point(826, 215);
            this.btnMedication.Name = "btnMedication";
            this.btnMedication.Size = new System.Drawing.Size(268, 56);
            this.btnMedication.TabIndex = 8;
            this.btnMedication.Text = "Medication";
            this.btnMedication.UseVisualStyleBackColor = false;
            this.btnMedication.Click += new System.EventHandler(this.btnMedication_Click);
            // 
            // DashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.btnMedication);
            this.Controls.Add(this.btnVaccination);
            this.Controls.Add(this.btnBloodDonation);
            this.Controls.Add(this.btnShowProfile);
            this.Controls.Add(this.ViewFamilyMembersForm);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.lblUserInfo);
            this.Controls.Add(this.lblWelcome);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "DashboardForm";
            this.Text = "DashboardForm";
            this.Load += new System.EventHandler(this.DashboardForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblUserInfo;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button ViewFamilyMembersForm;
        private System.Windows.Forms.Button btnShowProfile;
        private System.Windows.Forms.Button btnBloodDonation;
        private System.Windows.Forms.Button btnVaccination;
        private System.Windows.Forms.Button btnMedication;
    }
}
