﻿using Health;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Health
{
    public partial class DashboardForm : Form
    {
        private int _userId;
        private string _userName;
        private string _role;

        // MAIN constructor that matches your login call: DashboardForm(userId, name, role)
        public DashboardForm(int userId, string userName, string role)
        {
            InitializeComponent();

            _userId = userId;
            _userName = userName;
            _role = role;

            // Set UI immediately (safe because InitializeComponent created the controls)
            lblWelcome.Text = "Welcome to Family Health Manager";
            lblUserInfo.Text = $"Logged in as: {_userName} ({_role})";

            // Optional: load user-specific data here, e.g. number of meds, upcoming reminders, etc.
        }

        // Optional parameterless constructor (if Designer requires it)
        public DashboardForm()
        {
            InitializeComponent();
            lblWelcome.Text = "Welcome to Family Health Manager";
            lblUserInfo.Text = "Logged in as: (guest)";
        }

        // Logout event handler - wire this to the Logout button (btnLogout)
        private void btnLogout_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show("Are you sure you want to log out?", "Confirm logout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                var login = new LoginForm();
                login.Show();
                this.Close(); // closes dashboard
            }
        }

        // If you want to perform actions when form loads, you can use this:
        private void DashboardForm_Load(object sender, EventArgs e)
        {
            // Example: refresh dashboard widgets, load reminders, etc.
        }

        private void lblWelcome_Click(object sender, EventArgs e)
        {

        }

        /*private void btnAddFamilyMember_Click_Click(object sender, EventArgs e)
        {
            var AddFamilyMember1 = new AddFamilyMember();
            AddFamilyMember1.Show();
            this.Hide();
        }*/

        private void ViewFamilyMembersForm_Click(object sender, EventArgs e)
        {
            var viewFamilyForm = new ViewFamilyMembersForm();
            viewFamilyForm.Show();  // Open the ViewFamilyMembersForm
            this.Hide();  // Optionally, hide the current DashboardForm
        }

        private void btnShowProfile_Click(object sender, EventArgs e)
        {

            var profileform= new ProfileForm();
            profileform.Show();  // Open the ViewFamilyMembersForm
            this.Hide();
        }

        private void btnBloodDonation_Click(object sender, EventArgs e)
        {
            // Open the Blood Donation Form
           /* BloodDonationForm bloodDonationForm = new BloodDonationForm(_userId);
            bloodDonationForm.Show();  // Show the Blood Donation Form
            this.Hide();  // Hide the DashboardForm*/
        }

        private void btnVaccination_Click(object sender, EventArgs e)
        {
            VaccinationForm vF = new VaccinationForm();
            vF.Show();  // Show the Blood Donation Form
            this.Hide();  // Hide the DashboardForm
        }

        private void btnMedication_Click(object sender, EventArgs e)
        {
            // Get the userId from session (or passed value)
            int userId = Session.UserId;

            MedicationForm mF = new MedicationForm(userId); // Pass userId
            mF.Show();  // Show the MedicationForm
            this.Hide();  // Hide the DashboardForm
        }


    }
}

