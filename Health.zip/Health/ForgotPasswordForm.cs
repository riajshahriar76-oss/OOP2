﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Health
{
    public partial class ForgotPasswordForm : Form
    {
        public ForgotPasswordForm()
        {
            InitializeComponent();
            InitializePlaceholders();
            pnlReset.Visible = false; // hidden until user found
        }

        private void InitializePlaceholders()
        {
            // Email/Phone placeholder
            txtEmailPhone.Text = "Enter your email or phone";
            txtEmailPhone.ForeColor = Color.Gray;
            txtEmailPhone.Enter += (s, e) => {
                if (txtEmailPhone.Text == "Enter your email or phone")
                {
                    txtEmailPhone.Text = "";
                    txtEmailPhone.ForeColor = Color.Black;
                }
            };
            txtEmailPhone.Leave += (s, e) => {
                if (string.IsNullOrWhiteSpace(txtEmailPhone.Text))
                {
                    txtEmailPhone.Text = "Enter your email or phone";
                    txtEmailPhone.ForeColor = Color.Gray;
                }
            };

            // New Password placeholder
            txtNewPassword.Text = "New password";
            txtNewPassword.ForeColor = Color.Gray;
            txtNewPassword.UseSystemPasswordChar = false;
            txtNewPassword.Enter += (s, e) => {
                if (txtNewPassword.Text == "New password")
                {
                    txtNewPassword.Text = "";
                    txtNewPassword.ForeColor = Color.Black;
                    txtNewPassword.UseSystemPasswordChar = true;
                }
            };
            txtNewPassword.Leave += (s, e) => {
                if (string.IsNullOrWhiteSpace(txtNewPassword.Text))
                {
                    txtNewPassword.UseSystemPasswordChar = false;
                    txtNewPassword.Text = "New password";
                    txtNewPassword.ForeColor = Color.Gray;
                }
            };

            // Confirm Password placeholder
            txtConfirmPassword.Text = "Confirm password";
            txtConfirmPassword.ForeColor = Color.Gray;
            txtConfirmPassword.UseSystemPasswordChar = false;
            txtConfirmPassword.Enter += (s, e) => {
                if (txtConfirmPassword.Text == "Confirm password")
                {
                    txtConfirmPassword.Text = "";
                    txtConfirmPassword.ForeColor = Color.Black;
                    txtConfirmPassword.UseSystemPasswordChar = true;
                }
            };
            txtConfirmPassword.Leave += (s, e) => {
                if (string.IsNullOrWhiteSpace(txtConfirmPassword.Text))
                {
                    txtConfirmPassword.UseSystemPasswordChar = false;
                    txtConfirmPassword.Text = "Confirm password";
                    txtConfirmPassword.ForeColor = Color.Gray;
                }
            };
        }

        // Search for user by email or phone
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string id = txtEmailPhone.Text.Trim();

            if (string.IsNullOrEmpty(id) || id == "Enter your email or phone")
            {
                MessageBox.Show("Please enter an email or phone to search.", "Input required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    // We check Email and Phone columns (change query if your columns differ)
                    string sql = "SELECT UserID, FullName, Email, Phone FROM Users WHERE Email = @id OR Phone = @id";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int userId = Convert.ToInt32(reader["UserID"]);
                                string name = reader["FullName"] != DBNull.Value ? reader["FullName"].ToString() : "(user)";
                                string email = reader["Email"] != DBNull.Value ? reader["Email"].ToString() : "";
                                string phone = reader["Phone"] != DBNull.Value ? reader["Phone"].ToString() : "";

                                // show summary and enable reset panel
                                lblInfo.Text = $"User found: {name}  {(email != "" ? (" | " + email) : "")}{(phone != "" ? (" | " + phone) : "")}";
                                lblInfo.ForeColor = Color.Green;
                                lblInfo.Visible = true;

                                // store found user id in panel's Tag to use in reset
                                pnlReset.Tag = userId;
                                pnlReset.Visible = true;
                            }
                            else
                            {
                                lblInfo.Text = "No user found with that email/phone.";
                                lblInfo.ForeColor = Color.Red;
                                lblInfo.Visible = true;
                                pnlReset.Visible = false;
                            }
                        }
                    }
                }
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show("Database error: " + sqlex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Reset password (runs when Reset button clicked)
        private void btnResetPassword_Click(object sender, EventArgs e)
        {
            // get user id from Tag
            if (pnlReset.Tag == null)
            {
                MessageBox.Show("No user selected. Search first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int userId = Convert.ToInt32(pnlReset.Tag);
            string newPwd = txtNewPassword.Text.Trim();
            string confirm = txtConfirmPassword.Text.Trim();

            if (string.IsNullOrEmpty(newPwd) || newPwd == "New password" ||
                string.IsNullOrEmpty(confirm) || confirm == "Confirm password")
            {
                MessageBox.Show("Please enter and confirm the new password.", "Input required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (newPwd != confirm)
            {
                MessageBox.Show("Passwords do not match. Try again.", "Mismatch", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Optional: basic password strength check
            if (newPwd.Length < 6)
            {
                MessageBox.Show("Password should be at least 6 characters.", "Weak password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string sql = "UPDATE Users SET Password = @pwd WHERE UserID = @uid";
                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@pwd", newPwd);
                        cmd.Parameters.AddWithValue("@uid", userId);

                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Password reset successful. Please login with your new password.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            // go back to login
                            var login = new LoginForm();
                            login.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Could not update password. Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show("Database error: " + sqlex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBackToLogin_Click(object sender, EventArgs e)
        {
            var login = new LoginForm();
            login.Show();
            this.Close();
        }
    }
}

