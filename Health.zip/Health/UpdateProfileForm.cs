﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Health
{
    public partial class UpdateProfileForm : Form
    {
        // Constructor
        public UpdateProfileForm()
        {
            InitializeComponent();
            LoadDetails();  // Load user details when the form loads
        }

        // Method to load user details into the form
        private void LoadDetails()
        {
            // Query to fetch user details based on UserId
            string query = "SELECT FullName, Phone, Email, Gender, DOB FROM Users WHERE UserID = @UserId";

            // Replace with your actual connection string
            string connectionString = @"Server=RIAJ-PROPERTY\SQLEXPRESS;Database=HEALTH_DB;Trusted_Connection=True;";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Set the parameter for UserId
                        command.Parameters.AddWithValue("@UserId", Session.UserId);  // Use logged-in user's ID

                        connection.Open();

                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            // Populate the textboxes with the retrieved data
                            txtName.Text = reader["FullName"].ToString();
                            txtPhone.Text = reader["Phone"].ToString();
                            txtEmail.Text = reader["Email"].ToString();
                            cmbGender.Text = reader["Gender"].ToString();
                            dtpDOB.Value = Convert.ToDateTime(reader["DOB"]);
                        }
                        else
                        {
                            MessageBox.Show("No details found for the given ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Close(); // Close the form if no data is found
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading user details: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // This method will be called when the "Update" button is clicked
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string newFullName = txtName.Text.Trim();
            string newPhone = txtPhone.Text.Trim();
            string newEmail = txtEmail.Text.Trim();
            string newGender = cmbGender.SelectedItem?.ToString() ?? "Other";
            DateTime newDOB = dtpDOB.Value;  // Use DateTime from DateTimePicker

            // Validation
            if (string.IsNullOrWhiteSpace(newFullName) || string.IsNullOrWhiteSpace(newPhone) || string.IsNullOrWhiteSpace(newEmail))
            {
                MessageBox.Show("All fields must be filled out.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Update query to modify the user details
            string query = "UPDATE Users SET FullName = @FullName, Phone = @Phone, Email = @Email, Gender = @Gender, DOB = @DOB WHERE UserID = @UserId";

            // Replace with your actual connection string
            string connectionString = @"Server=RIAJ-PROPERTY\SQLEXPRESS;Database=HEALTH_DB;Trusted_Connection=True;";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Set the parameters for updating user info
                        command.Parameters.AddWithValue("@FullName", newFullName);
                        command.Parameters.AddWithValue("@Phone", newPhone);
                        command.Parameters.AddWithValue("@Email", newEmail);
                        command.Parameters.AddWithValue("@Gender", newGender);
                        command.Parameters.AddWithValue("@DOB", newDOB);
                        command.Parameters.AddWithValue("@UserId", Session.UserId);  // Use logged-in user's ID

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //this.Close(); // Optionally close the form after a successful update
                        }
                        else
                        {
                            MessageBox.Show("No record was updated. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating record: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Back button click handler to go back to Profile Form
        private void btnBack_Click(object sender, EventArgs e)
        {
            DashboardForm dashboardForm = new DashboardForm();

            // Show the DashboardForm
            dashboardForm.Show();

            // Hide the current ViewFamilyMembersForm
            this.Hide();
        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            ProfileForm profileForm = new ProfileForm();

            // Show the DashboardForm
            profileForm.Show();

            // Hide the current ViewFamilyMembersForm
            this.Hide();
        }
    }
}
